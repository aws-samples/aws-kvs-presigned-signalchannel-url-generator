import { KvsClient } from './kvsClient.mjs'

const region = process.env.AWS_REGION || 'us-east-1'
const credentials = { accessKeyId: process.env.AWS_ACCESS_KEY_ID, secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY  }

export const handler = async(event) => {
    
    const params = event.queryStringParameters
    const channelName = params.channelName
    
    const kvsClient = new KvsClient(region, credentials)
    
    const channelARN = await kvsClient.getSignalingChannelARN(channelName)
    const signalingChannelEndpoints = await kvsClient.getSignalingChannelEndpoints(channelARN)
    const signedURL = await kvsClient.getSignedSignalingChannelEndpoint(channelARN, signalingChannelEndpoints, 'master')
    
    const responsePayload = { 'signedURL': signedURL }
    
    const response = {
        statusCode: 200,
        "headers": {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(responsePayload),
    };
    return response;
};


# Configuration

Requires an IAM Role attached to the Lambda Execution Role with the following policy:

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "kinesisvideo:GetSignalingChannelEndpoint",
                "kinesisvideo:GetIceServerConfig",
                "kinesisvideo:ConnectAsViewer",
                "kinesisvideo:DescribeSignalingChannel"
            ],
            "Resource": "arn:aws:kinesisvideo:{{AWS_REGION}}:{{AWS_ACCOUNT_NUMBER}}:channel/*/*"
        }
    ]
}
```
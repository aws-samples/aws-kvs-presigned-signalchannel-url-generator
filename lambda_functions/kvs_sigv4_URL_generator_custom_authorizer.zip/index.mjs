import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async(event) => {
    
    let response = {
        "isAuthorized": false
        
    };
    
    const email = event.headers.email;
    const camera = event.headers.cameraname;
    
    console.log("Email: " + JSON.stringify(email));
    console.log("Camera name: " + JSON.stringify(camera));
    
    const command = new GetCommand({
        TableName: "Users",
        Key: {
            email: email,
        }});

    const doc_response = await docClient.send(command);
    let isApprovedResult = doc_response["Item"]["Cameras"].indexOf(camera);
    
    if (event.headers.authorization === "secretToken") {
        if(isApprovedResult != -1 ){
            response = {
                "isAuthorized": true 
            };
        }
        
    }

    return response;

};